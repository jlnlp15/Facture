package com.example.login_egypte

import androidx.compose.runtime.Composable
import androidx.navigation.NavHost
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.composable
import androidx.navigation.NavType

@Composable
fun Nav() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "login" ) {
        composable("login") {
            LoginDisplay(navController)
        }
        composable("Facture") {
            AccueilDisplay(navController)
        }

    }

}